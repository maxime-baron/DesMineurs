#ifndef JOUEUR_H
#define JOUEUR_H

#include "Demineur.h"

class Demineur;

class Joueur
{
private:
    Demineur * monDemineur;
public:
    Joueur();
};

#endif // JOUEUR_H
