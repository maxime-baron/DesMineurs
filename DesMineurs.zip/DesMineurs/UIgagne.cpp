#include "UIgagne.h"

UIgagne::UIgagne()
{
}
